import logo from "./logo.svg";
import "./App.css";
import "./css/style.css"

import Box from "@mui/material/Box";
import form, { Button, Stack } from "@mui/material";
import { Grid, TextField } from "@mui/material";
import React from "react";
import "./css/style.css"
// import KeyIcon from '@mui/icons-material/Key';
import LoginIcon from '@mui/icons-material/Login';


// const samplepicture =new URL("./images/sample.jpg",import.meta.url)
// function App() { 

//   return <>
//   <section className="main-container">
// <p>hello</p>
// <div className="samplepicture">
//   <img src={samplepicture}/>
// </div>
// </section>
//   </>

// }
// export default App
                    {/* <KeyIcon>
                                <p>jflks</p>
                                </KeyIcon>
                               
                                 */}
const samplepicture =new URL("./images/sample.jpg",import.meta.url)

function App() {
  return <>
        <Box alignItems={"center"}>
        <Box sx={{ backgroundColor: 'white', borderRadius: '10px', boxShadow: 11}}>
          <Grid container justifyContent='center' sx={{ textAlign: 'center' }}  spacing={4} >

    <Box  sx={{ border:"1px solid black",p:10 ,borderColor:'#d2cbcb;' , borderRadius:'4px',':hover': {  boxShadow:2} ,mt:5  }} >
     
    <Grid container>
    <Grid className="samplepicture">
    <img src={samplepicture}/>
 </Grid>
 <Grid>
 <Box  sx={{ border:"1px solid black" , p:4 ,borderColor:'#d2cbcb;' , borderRadius:'4px',':hover': {  boxShadow:2} ,mt:5  }} >
  <Box>
    <h1>Welcome Back</h1>
    <p>Please Enter Your Email and Password</p>
    <Grid>
    <TextField fullWidth id="Email" label="Email id" variant="outlined" size='small'color='secondary'
      />
      </Grid>
      <Grid sx={{mt:2}}>
       <TextField   fullWidth  id="MobileNum" label="Password" required variant="outlined"  size='small'color='secondary'
                                    inputProps={{
                                        maxLength: 10
                                    }}
                                   
                                  
                                />
                                </Grid>
                                <p>By login, you agree to our Terms & Conditions</p>
                                <Grid container>
                                <Grid>
                                    <Stack spacing={2} direction="row" >
                                        <Button 
                                       
                                         variant="outlined"
                                            type='submit' sx={{ color: 'white', backgroundColor: '#FA7124', borderRadius: '5px 18px', ':hover': {  borderColor: '#FA7124', color: '#000000'} }}>Login 

                                            <LoginIcon sx={{ml:1}}></LoginIcon>
                                            </Button>
                                      
                                    </Stack>
                                    
                                    <Box></Box>
                              
                                </Grid>
                               
                               
                            
                                </Grid>
                               
  </Box>
 <Grid>
 
 </Grid>

 </Box>
 </Grid>
 
  
    </Grid>
   
    </Box>
          </Grid>
        </Box>
        </Box>
    
        </>
}

export default App;
